package com.realweather.treephysics.physics;

import java.util.ArrayList;
import java.util.List;

/**
 * One rigid segment of the skeleton (a trunk piece or a branch/twig).
 *
 * Orientation is tracked as two small angles measured from this bone's
 * REST pose, relative to its parent's local frame:
 *   - bend: lean in the direction the wind is currently pushing
 *   - sway: motion perpendicular to the wind (the side-to-side wobble
 *           you see in real branches, driven by how the bend oscillates)
 *
 * This two-angle model is a deliberate simplification of full 3D rigid
 * body rotation (no twist axis). It's cheap, numerically stable, and
 * visually matches how real trunks/branches actually move in wind.
 */
public class TreeBone {
    public final float length;
    public final float baseRadius;
    public final float tipRadius;

    /** Rest orientation offset from the parent bone, in radians. */
    public final float restPitch;
    public final float restYaw;

    /** Spring stiffness: how hard this bone pulls back toward rest. */
    public final float stiffness;
    /** Velocity damping: how fast oscillation dies down. */
    public final float damping;
    /** How much wind force this bone actually catches (leafy twigs catch more than bare trunk). */
    public final float windDrag;

    public float bend;
    public float sway;
    public float bendVel;
    public float swayVel;

    public final List<TreeBone> children = new ArrayList<>();

    public TreeBone(float length, float baseRadius, float tipRadius,
                     float restPitch, float restYaw,
                     float stiffness, float damping, float windDrag) {
        this.length = length;
        this.baseRadius = baseRadius;
        this.tipRadius = tipRadius;
        this.restPitch = restPitch;
        this.restYaw = restYaw;
        this.stiffness = stiffness;
        this.damping = damping;
        this.windDrag = windDrag;
    }
}
