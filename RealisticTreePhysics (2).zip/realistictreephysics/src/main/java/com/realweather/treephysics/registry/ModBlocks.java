package com.realweather.treephysics.registry;

import com.realweather.treephysics.TreePhysicsMod;
import com.realweather.treephysics.block.PhysicsTreeBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(TreePhysicsMod.MODID);

    // v1 ships one registered block; visual variety comes from the
    // procedural generator's per-position seed (see TreeSkeleton.generate).
    public static final DeferredBlock<PhysicsTreeBlock> PHYSICS_OAK =
            BLOCKS.register("physics_oak", () -> new PhysicsTreeBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.WOOD)
                            .strength(2.0f)
                            .sound(SoundType.WOOD)
                            .noOcclusion()
            ));
}
