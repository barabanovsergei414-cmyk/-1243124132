package com.realweather.treephysics.physics;

/**
 * Integrates one damped spring per bending axis of a bone:
 *
 *   angularAccel = windForce * windDrag
 *                  - stiffness * currentDisplacement
 *                  - damping   * currentVelocity
 *                  + parentVelocity * carryFactor   (so shaking a trunk
 *                                                     also nudges its branches)
 *
 * This is explicit (semi-implicit Euler) integration, which is fine at a
 * fixed 20 Hz tick rate with the stiffness/damping ranges used by
 * TreeSkeleton - those were picked to stay stable at dt = 1/20s.
 */
public final class SpringDamperPhysics {
    private SpringDamperPhysics() {}

    private static final float PARENT_MOTION_CARRY = 0.15f;
    private static final float MAX_ANGLE_RADIANS = 0.9f; // ~51 degrees, keeps bends physically plausible

    public static void step(TreeBone bone, float windAlong, float windAcross,
                             float parentBendVel, float parentSwayVel, float dt) {
        float bendAccel = (windAlong * bone.windDrag)
                - bone.stiffness * bone.bend
                - bone.damping * bone.bendVel
                + parentBendVel * PARENT_MOTION_CARRY;
        float swayAccel = (windAcross * bone.windDrag)
                - bone.stiffness * bone.sway
                - bone.damping * bone.swayVel
                + parentSwayVel * PARENT_MOTION_CARRY;

        bone.bendVel += bendAccel * dt;
        bone.swayVel += swayAccel * dt;

        bone.bend = clamp(bone.bend + bone.bendVel * dt);
        bone.sway = clamp(bone.sway + bone.swayVel * dt);
    }

    private static float clamp(float v) {
        return Math.max(-MAX_ANGLE_RADIANS, Math.min(MAX_ANGLE_RADIANS, v));
    }
}
