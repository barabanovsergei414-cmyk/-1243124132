package com.realweather.treephysics.registry;

import com.realweather.treephysics.TreePhysicsMod;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(TreePhysicsMod.MODID);

    public static final DeferredItem<Item> PHYSICS_OAK_ITEM =
            ITEMS.registerSimpleBlockItem("physics_oak", ModBlocks.PHYSICS_OAK);
}
