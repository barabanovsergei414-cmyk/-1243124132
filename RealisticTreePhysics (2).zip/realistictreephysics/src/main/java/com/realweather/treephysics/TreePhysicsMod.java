package com.realweather.treephysics;

import com.realweather.treephysics.config.TreePhysicsConfig;
import com.realweather.treephysics.registry.ModBlockEntities;
import com.realweather.treephysics.registry.ModBlocks;
import com.realweather.treephysics.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(TreePhysicsMod.MODID)
public class TreePhysicsMod {
    public static final String MODID = "treephysics";

    public TreePhysicsMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);

        modContainer.registerConfig(ModConfig.Type.COMMON, TreePhysicsConfig.SPEC);
    }
}
